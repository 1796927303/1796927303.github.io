import { defineConfig } from 'astro/config';

// https://astro.build/config
export default defineConfig({
  site: 'https://1796927303.github.io',
  // 当使用 username.github.io 作为仓库名时，不需要设置 base
});